__global__ void dev_reverb_shrink_H(int stride, int dStride, float ratio, float *source, float *target)
{
	// Work out index in dest layer
	int idx = blockIdx.x * blockDim.x + threadIdx.x;
	int idy = blockIdx.y * blockDim.y + threadIdx.y;

	int		tIDd = threadIdx.x;
	float 	tIDf = threadIdx.x;

	int lb = ceil((tIDf) * ratio);
	int ub = floor((tIDf + 0.9999f) * ratio) + 1.0f; 

	// dynamic shared memory arrays!
	float* temp  = (float*)memPool;
	float* tempOut = (float*)&memPool[stride];

	// each thread loads all the elements it needs and inits it's output
	tempOut[tIDd] = 0;
	for (int i = lb; i < ub; ++i) {
		temp[i] = source[i + stride * idy];
		tempOut[tIDd] += temp[i];
	}
	tempOut[tIDd] /= float(ub-lb);

	// return result to main memory
	target[idx + dStride * idy] = tempOut[tIDd];
	
}

__global__ void dev_reverb_shrink_V(int stride, int dStride, float ratio, float *source, float *target, float weight)
{
	// Work out index in dest layer
	int idx = blockIdx.x * blockDim.x + threadIdx.x;
	int idy = blockIdx.y * blockDim.y + threadIdx.y;

	int		tIDd = threadIdx.y;
	float 	tIDf = threadIdx.y;

	int lb = ceil((tIDf) * ratio);
	int ub = floor((tIDf + 0.9999f) * ratio) + 1.0f; 

	// dynamic shared memory arrays!
	float* temp  = (float*)memPool;
	float* tempOut = (float*)&memPool[stride];

	// each thread loads all the elements it needs and inits it's output
	tempOut[tIDd] = 0;
	for (int i = lb; i < ub; ++i) {
		temp[i] = source[idx + dStride * i];
		tempOut[tIDd] += temp[i];
	}
	tempOut[tIDd] *= weight / float(ub-lb);

	// return result to main memory
	target[idx + dStride * idy] = tempOut[tIDd];
}

__global__ void dev_reverb_expand_H(int stride, int dStride, float ratio, float *source, float *target)
{
	// Work out index in dest layer
	int idx = blockIdx.x * blockDim.x + threadIdx.x;
	int idy = blockIdx.y * blockDim.y + threadIdx.y;

	int		tIDd = threadIdx.x;
	float 	tIDf = threadIdx.x;

	int lb = ceil((tIDf) * ratio);
	int ub = floor((tIDf + 0.9999f) * ratio) + 1.0f; 

	// dynamic shared memory arrays!
	float* temp  = (float*)memPool;
	float* tempOut = (float*)&memPool[stride];

	// each thread loads all the elements it needs and inits it's output
	tempOut[tIDd] = 0;
	for (int i = lb; i < ub; ++i) {
		temp[i] = source[i + stride * idy];
		tempOut[tIDd] += temp[i];
	}
	tempOut[tIDd] /= float(ub-lb);

	// return result to main memory
	target[idx + dStride * idy] = tempOut[tIDd];
	
}




extern "C" void REVERB_Resize(cudaLINlayer &src, cudaLINlayer &dst, dim3 &dimGrid, dim3 &dimBlock,float *source, float *dest, float *temp, float weight)
{

	int srcWidth = src.sizeX;
	int srcHeight = src.sizeY;
	int dstWidth = dst.sizeX;
	int dstHeight = dst.sizeY;


	// we've already checked for squareness, so now we need only compare one dim
	if (dstWidth < srcWidth) {

		dim3 threadDims(dstWidth,1);
		dim3 blockDims(1,srcHeight);

		float ratio = float(srcWidth) / float(dstWidth);

	   	dev_reverb_shrink_H <<< blockDims, threadDims, (srcWidth + dstWidth) * sizeof(float) >>>(srcWidth, dstWidth, ratio, source, temp);

		dim3 threadDimsV(1,dstWidth);// dstWidth
		dim3 blockDimsV(dstHeight,1);

		ratio = float(srcHeight) / float(dstHeight);

	   	dev_reverb_shrink_V <<< blockDimsV, threadDimsV, (srcWidth + dstWidth) * sizeof(float) >>>(srcWidth, dstWidth, ratio, temp, dest, weight);

	} else if (dstWidth == srcWidth) {

		reverb_kernel_array_add <<< dimGrid, dimBlock >>> (dst.sizeX, dst.sizeY, source, dest, weight);

	} else {

		dim3 threadDims(dstWidth,1);
		dim3 blockDims(1,srcHeight);

		float ratio = float(srcWidth) / float(dstWidth);

	   	dev_reverb_expand_H <<< blockDims, threadDims, (srcWidth + dstWidth) * sizeof(float) >>>(srcWidth, dstWidth, ratio, source, temp);
		

	}

}
