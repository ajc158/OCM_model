/*

	This file is an interface to a CUDA implementation of the REVERB Oculomotor system. 

	Programmed By: David R W Barr (University of Manchester)
	Tuned By: Alex Cope & Jon Chambers (University of Sheffield)

	- 2009 -

	By default the model is tuned to stimuli approximately 20 pixels in diameter, 
	on a 128x128 stimulus layer.

*/

#ifdef __cplusplus
#define CHECK_EXT extern "C"
#else
#define CHECK_EXT
#endif

#ifndef REVERB_CUDA_H
#define REVERB_CUDA_H

// output function identifiers
#define LINEAR		0
#define TANH		1
#define EXP			2


// projection type identifiers
#define ONETOONE	0
#define DIFFUSE		1
#define GAUSSIAN	2

// synapse type identifiers
#define ADD			0
#define SHUNT		1

struct cudaLINlayer {

	string 	name;
	int		sizeX;
	int		sizeY;
	float	lambda_m;
	float   p;
	float 	c;
	float 	m;
	int		type;

};

struct cudaLINproj {

	string 	name;
	int		srcID;
	int 	dstID;
	int		type;
	int 	syn;
	float	weight;
	VSINGLE extra;	

}; 


// Construct the model with all layers of the specified dimensions
CHECK_EXT void CreateSystem(vector < cudaLINlayer > layers, vector < cudaLINproj > projs)

// Use the parameters above
//CHECK_EXT void REVERB_SetParameter(int parameter, float value);

// Release all memory used by the model
CHECK_EXT void DestroySystem()

// Probe the output of a specific layer
CHECK_EXT void ProbeSystem(float* data, int layer)

// Perform one update cycle using a pre-normalised stimulus
CHECK_EXT void StepSystem(int width, int height, vector < float* > inputs);


#endif
