
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% A OCM-CUDA  example template scrip %
%%%%%%%%%%% Alex Cope 2010 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
executionStop = 10;
fS = 400;
num_samples = fS * executionStop;



%% BUILDING THE SYSTEM

sys = sml_system; % our top level system

state = {};

sys = sys.addprocess('oculo', 'dev/abrg/2010/oculo', fS, state);


state = {};
state.data = zeros(128);

state.data(20:25,50:55) = 0.4;

state.data(70:75,50:55) = 0.3;

state.data(70:75,80:85) = 0.3;

state.data(1) = 1;
state.ndims = 2;
state.repeat = true;

sys = sys.addprocess('src', 'std/2009/source/numeric', fS, state);

sys = sys.link('src>out', 'oculo<in', 0);

%% CONFIGURE AND LAUNCH BRAHMS
cmd = brahms_execution;
cmd.name = 'modlin_test';
cmd.stop = executionStop;
cmd.all = false;
cmd.encapsulated = false;
cmd.execPars.MaxThreadCount = 'x2'; % Max two threads per processor


% call BRAHMS
[out, rep] = brahms(sys, cmd);


%% PROCESS RESULTS


imagesc(out.oculo.out(:,:,600)); colormap(hot); colorbar
