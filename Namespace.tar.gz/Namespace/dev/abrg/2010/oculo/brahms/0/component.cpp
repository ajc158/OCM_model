/* 
________________________________________________________________

	This file is part of BRAHMS
	Copyright (C) 2007 Ben Mitchinson
	URL: http://brahms.sourceforge.net

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
________________________________________________________________

	Subversion Repository Information (automatically updated on commit)

	$Id:: process.cpp 2067 2009-06-13 23:50:44Z benjmitch      $
	$Rev:: 2067                                                $
	$Author:: benjmitch                                        $
	$Date:: 2009-06-14 00:50:44 +0100 (Sun, 14 Jun 2009)       $
________________________________________________________________

*/



////////////////	COMPONENT INFO

//	define your component information here. if you use the BRAHMS
//	Manager to create your process, it will insert sensible defaults.
#define COMPONENT_CLASS_STRING "dev/abrg/2010/oculo"
#define COMPONENT_CLASS_CPP dev_abrg_2010_oculo_0 
#define COMPONENT_RELEASE 0
#define COMPONENT_REVISION 1
#define COMPONENT_ADDITIONAL "Author=alex\n" "URL=Not supplied\n"
#define COMPONENT_FLAGS (F_NOT_RATE_CHANGER)

//	we define this symbol to ask the template to include the basics
//	we usually need to build a process. it will import the "brahms"
//	namespace and include the header files (SDK) for the data and util
//	classes from the Standard Library.
#define OVERLAY_QUICKSTART_PROCESS

#define _CRT_SECURE_NO_DEPRECATE

#define __WIN__

//	include the core overlay (component bindings 1199)
#include "brahms-1199.h"

   /*
//	windows only
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include "windows.h"
#undef RGB
#endif */

//	STL includes
#include <ctime>
#include <cmath>
#include <sstream>
#include <iostream>
#include <vector>
#include <time.h>
#include <stdlib.h>
#include <ctime>

using namespace std;


//	alias data and util namespaces to something briefer
namespace numeric = std_2009_data_numeric_0;
namespace spikes = std_2009_data_spikes_0;
namespace rng = std_2009_util_rng_0;

////////////////	COMPONENT CLASS (DERIVES FROM Process)

#include "ReverbCuda.h"

class COMPONENT_CLASS_CPP : public Process
{


public:

	//	use ctor/dtor only if required
	COMPONENT_CLASS_CPP() {}
	~COMPONENT_CLASS_CPP() {}

	//	the framework event function
	Symbol event(Event* event);




private:


	numeric::Input  input;
	numeric::Output output;

};


////////////////	EVENT

Symbol COMPONENT_CLASS_CPP::event(Event* event)
{
	switch(event->type)
	{
		case EVENT_STATE_SET:
		{
			
			//	extract DataML
			EventStateSet* data = (EventStateSet*) event->data;
			XMLNode xmlNode(data->state);
			DataMLNode nodeState(&xmlNode);
					
			REVERB_Oculomotor_Create(128, 128);
			
			return C_OK;
		}

		case EVENT_INIT_CONNECT:
		{
			//	on first call
			if (event->flags & F_FIRST_CALL)
			{
				output.setName("out");
				output.create(hComponent);
				output.setStructure(TYPE_DOUBLE | TYPE_REAL, Dims(128,128).cdims());

			}

			//	on last call
			if (event->flags & F_LAST_CALL)
			{
				
				input.attach(hComponent, 0);
	
			}

			//	ok
			return C_OK;
		}


		case EVENT_INIT_POSTCONNECT:
		{



			return C_OK;
		}

		case EVENT_RUN_SERVICE:
		{
			
			UINT32 arraySize = 128*128;

			DOUBLE* inData = (DOUBLE*) input.getContent();

			VSINGLE stimulus_in;

			stimulus_in.resize(arraySize,0);

			for (UINT32 i = 0; i < arraySize; ++i) {

				stimulus_in[i] = (SINGLE) inData[i];

			}
			
			REVERB_Oculomotor_Update(128, 128, &(stimulus_in[0]));
			
			VSINGLE readback;

			readback.resize(arraySize,0);

			DOUBLE* outData = (DOUBLE*) output.getContent();

			REVERB_Oculomotor_Probe(&readback[0], 7);	

			for (UINT32 i = 0; i < arraySize; ++i) {

				outData[i] = (DOUBLE) readback[i];

			}			

 			//	ok
			return C_OK;
		}

		case EVENT_RUN_STOP:
		{



			return C_OK;
		}

	}


	//	if we service the event, we return C_OK
	//	if we don't, we should return S_NULL to indicate that we didn't
	return S_NULL;
}







//	include the second part of the overlay (it knows you've included it once already)
#include "brahms-1199.h"

