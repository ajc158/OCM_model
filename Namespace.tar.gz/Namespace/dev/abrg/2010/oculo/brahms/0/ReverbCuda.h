/*

	This file is an interface to a CUDA implementation of the REVERB Oculomotor system. 

	Programmed By: David R W Barr (University of Manchester)
	Tuned By: Alex Cope & Jon Chambers (University of Sheffield)

	- 2009 -

	By default the model is tuned to stimuli approximately 20 pixels in diameter, 
	on a 128x128 stimulus layer.

*/

#ifdef __cplusplus
#define CHECK_EXT extern "C"
#else
#define CHECK_EXT
#endif

#ifndef REVERB_CUDA_H
#define REVERB_CUDA_H

// Weight and SD Identifiers
#define DIFFUSE_SCALING_COEF	0 // READ ONLY
#define BG_SCALING_COEF			1
#define DOPAMINE				2
#define RET2_FEF				3
#define THAL_D1					4
#define THAL_D2					5
#define THAL_STN				6
#define FEF_D1					7
#define FEF_D2					8
#define FEF_STN					9
#define THAL_FEF				10
#define FEF_THAL				11
#define FEF_SCB					12
#define FEF_SCB_SD				13 
#define THAL_STN_SD				14 
#define FEF_STN_SD				15 
#define SD1_GPI					16 
#define SD2_GPE					17
#define GPE_GPI					18
#define GPE_STN					19
#define STN_GPE					20
#define STN_GPI					21
#define GPI_THAL_MULT			22
#define GPI_THAL_ADD			23
#define GPI_SCB_MULT			24
#define GPI_SCB_ADD				25
#define SCB_SCB					26
#define SCB_SCB_SD				27
#define SCB_THAL				28
#define SCS_THAL				29
#define SCS_SCB					30
#define RET1_FEF				31
#define RET1_FEF_SD				32 
#define RET1_SCS				33
#define RET1_SCS_SD				34 
#define RET2_RET1				35
#define SD1_OFFSET				36
#define SD2_OFFSET				37
#define GPE_OFFSET				38
#define GPI_OFFSET				39
#define FEF_OFFSET				40
#define RET1_OFFSET				41
#define RET2_OFFSET				42
#define LAYER_TAU				43
#define LAYER_FPS				44
#define RET1_TAU				45
#define RET1_FPS				46
#define RET2_TAU				47
#define RET2_FPS				48

// Neuron Layer Identifiers
#define LAYER_STN	0
#define LAYER_SD1	1
#define LAYER_SD2	2
#define LAYER_GPE	3
#define LAYER_GPI	4
#define LAYER_THAL	5
#define LAYER_FEF	6
#define LAYER_SCB	7
#define LAYER_SCS	8
#define LAYER_RET1	9
#define LAYER_RET2	10



// Construct the model with all layers of the specified dimensions
CHECK_EXT void REVERB_Oculomotor_Create(int width, int height);

// Use the parameters above
CHECK_EXT void REVERB_SetParameter(int parameter, float value);

// Release all memory used by the model
CHECK_EXT void REVERB_Oculomotor_Destroy(int width, int height);

// Probe the output of a specific layer, listed above
CHECK_EXT void REVERB_Oculomotor_Probe(float* data, int layer);

// Perform one update cycle using a pre-normalised stimulus
CHECK_EXT void REVERB_Oculomotor_Update(int width, int height, float* stimulus_in);


#endif
