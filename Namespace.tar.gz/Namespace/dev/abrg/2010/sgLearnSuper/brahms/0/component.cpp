
/*

	This is a newly created BRAHMS Process. It is a native
	process, and needs to be built before BRAHMS can run it.
	In Matlab, run "brahms_manager", select this component,
	and click on "Build". After doing this, you can build it
	in future using "brahms_utils".

*/



////////////////	COMPONENT INFO

//	define your component information here. if you use the BRAHMS
//	Manager to create your process, it will insert sensible defaults.
#define COMPONENT_CLASS_STRING "dev/abrg/2010/sgLearnSuper"
#define COMPONENT_CLASS_CPP dev_abrg_2010_sgLearnSuper_0
#define COMPONENT_RELEASE 0
#define COMPONENT_REVISION 1
#define COMPONENT_ADDITIONAL "Author=alex\n" "URL=Not supplied\n"
#define COMPONENT_FLAGS (F_NOT_RATE_CHANGER)

//	we define this symbol to ask the template to include the basics
//	we usually need to build a process. it will import the "brahms"
//	namespace and include the header files (SDK) for the data and util
//	classes from the Standard Library.
#define OVERLAY_QUICKSTART_PROCESS

//	include the component interface overlay (component bindings 1199)
#include "brahms-1199.h"

#define pi 	3.14159265358979323846

//	STL includes
#include <cmath>
#include <sstream>
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

//	alias data and util namespaces to something briefer
namespace numeric = std_2009_data_numeric_0;
namespace spikes = std_2009_data_spikes_0;
namespace rng = std_2009_util_rng_0;





////////////////	COMPONENT CLASS (DERIVES FROM Process)

class COMPONENT_CLASS_CPP : public Process
{

public:

	//	use ctor/dtor only if required
	COMPONENT_CLASS_CPP() {}
	~COMPONENT_CLASS_CPP() {}

	//	the framework event function
	Symbol event(Event* event);

private:

	INT32 	saccadeDetect;
	DOUBLE	prevH;
	DOUBLE 	prevV;
	UINT32	scArrayIndex;
	UINT32 counter;

	//	inputs and outputs
	numeric::Input plantH;
	numeric::Input plantV;

	numeric::Output reset;
	numeric::Output scIn;
	numeric::Output errorU;
	numeric::Output errorD;
	numeric::Output errorL;
	numeric::Output errorR;


};



////////////////	EVENT

Symbol COMPONENT_CLASS_CPP::event(Event* event)
{
	switch(event->type)
	{
		case EVENT_STATE_SET:
		{
			//	extract DataML
			EventStateSet* data = (EventStateSet*) event->data;
			XMLNode xmlNode(data->state);
			DataMLNode nodeState(&xmlNode);

			saccadeDetect = 0;
			prevH = 0;
			prevV = 0;
			scArrayIndex = 0;
			counter = 0;

			//	ok
			return C_OK;
		}

		case EVENT_INIT_CONNECT:
		{
			//	on first call
			if (event->flags & F_FIRST_CALL)
			{


				//	reset signal to neurons
				reset.setName("reset");
				reset.create(hComponent);
				reset.setStructure(TYPE_REAL | TYPE_DOUBLE, Dims(1).cdims());

				// training input
				scIn.setName("sc");
				scIn.create(hComponent);
				scIn.setStructure(TYPE_REAL | TYPE_DOUBLE, Dims(32,32).cdims());

				// calculated errors for the learning modules
				errorU.setName("errorU");
				errorU.create(hComponent);
				errorU.setStructure(TYPE_REAL | TYPE_DOUBLE, Dims(1).cdims());

				errorD.setName("errorD");
				errorD.create(hComponent);
				errorD.setStructure(TYPE_REAL | TYPE_DOUBLE, Dims(1).cdims());

				errorL.setName("errorL");
				errorL.create(hComponent);
				errorL.setStructure(TYPE_REAL | TYPE_DOUBLE, Dims(1).cdims());

				errorR.setName("errorR");
				errorR.create(hComponent);
				errorR.setStructure(TYPE_REAL | TYPE_DOUBLE, Dims(1).cdims());


			}

			//	on last call
			if (event->flags & F_LAST_CALL)
			{


				// inputs from the motor plant
				plantH.attach(hComponent, "plantH");
				plantH.validateStructure(TYPE_REAL | TYPE_DOUBLE, Dims(1).cdims());

				plantV.attach(hComponent, "plantV");
				plantV.validateStructure(TYPE_REAL | TYPE_DOUBLE, Dims(1).cdims());


			}

			//	ok
			return C_OK;
		}

		case EVENT_RUN_SERVICE:
		{

			++counter;
			
			//	get data object on input port and access its content
			DOUBLE h = ((DOUBLE*) plantH.getContent())[0];
			DOUBLE v = ((DOUBLE*) plantV.getContent())[0];

			// get output memory
			DOUBLE* resetPort = (DOUBLE*) reset.getContent();
			DOUBLE* scArray = (DOUBLE*) scIn.getContent();
			DOUBLE* errU = (DOUBLE*) errorU.getContent();
			DOUBLE* errD = (DOUBLE*) errorD.getContent();
			DOUBLE* errL = (DOUBLE*) errorL.getContent();
			DOUBLE* errR = (DOUBLE*) errorR.getContent();

			errU[0] = 999;
			errD[0] = 999;
			errL[0] = 999;
			errR[0] = 999;

			// if we haven't seen movement and movement occurs:
			if (saccadeDetect == 0 && (abs(prevH - h) > 0.001 || abs(prevV - v) > 0.001)) {
				saccadeDetect = 1;
			}			

			// if we've seen movement and it stops:
			if ((saccadeDetect == 1 && (abs(prevH - h) < 0.001 && abs(prevV - v) < 0.001)) || (counter > 600)) {
				saccadeDetect = -10;


				if (abs(v) > 0.01 || abs(h) > 0.01) {

					// calculate where we should have been (x and y flipped due to stupid matlab convention):
						DOUBLE y = scArrayIndex % 32;
						DOUBLE x = (scArrayIndex - y) / 32.0;
					
						y = (y - 16) / 16; 
						x = (x - 16) / 16; 
				
					// calculate error:
					/*	if (y > 0) { 
							errU[0] = (-v - y);
							errD[0] = 0;
						} else {
							errD[0] = -(-v - y);
							errU[0] = 0;
						}
						if (x > 0) {
							errR[0] = -(h - x);
							errL[0] = 0;
						} else {
							errL[0] = (h - x);
							errR[0] = 0;
						}*/


							errU[0] = (-v - y);
							errD[0] = -(-v - y);
							errR[0] = -(h - x);
							errL[0] = (h - x);

			
//bout << "report: index=" << scArrayIndex << " H=" << h << " V=" << v << " Hact=" << x << " Vact=" << y << " errorU=" << errU[0] << " errorD=" << errD[0] << " errorL=" << errL[0] << " errorR=" << errR[0] << D_WARN;
	
					} else {

					// no saccade!
						errU[0] = 0.1;
						errD[0] = 0.1;
						errR[0] = 0.1;
						errL[0] = 0.1;

					}

				// move the input spot to random location
				scArrayIndex = rand() % 1024;
				
				//++scArrayIndex;
				//if (scArrayIndex > (32 * 32) -1); 
scArrayIndex = 16+32+32+32+32+32+32+32+32+32+32+32+32+32+32;

			}		

			if (counter > 600) {

				counter = 0;

			} 	
	
			// reset for 10 iters
			if (saccadeDetect < 0) {
				resetPort[0] = 1;
				++saccadeDetect;
			} else {
				resetPort[0] = 0;
			}

			// create scArray
			for (UINT32 i = 0; i < 32*32; ++i) {
				scArray[i] = 0;
			}
			scArray[scArrayIndex] = 1;			

			prevH = h;
			prevV = v;

			//	ok
			return C_OK;
		}

	}

	//	if we service the event, we return C_OK
	//	if we don't, we should return S_NULL to indicate that we didn't
	return S_NULL;
}







//	include the second part of the overlay (it knows you've included it once already)
#include "brahms-1199.h"

