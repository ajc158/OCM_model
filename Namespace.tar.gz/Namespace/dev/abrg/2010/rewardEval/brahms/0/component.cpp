
/*

	This is a newly created BRAHMS Process. It is a native
	process, and needs to be built before BRAHMS can run it.
	In Matlab, run "brahms_manager", select this component,
	and click on "Build". After doing this, you can build it
	in future using "brahms_utils".

*/



////////////////	COMPONENT INFO

//	define your component information here. if you use the BRAHMS
//	Manager to create your process, it will insert sensible defaults.
#define COMPONENT_CLASS_STRING "dev/abrg/2010/rewardEval"
#define COMPONENT_CLASS_CPP dev_abrg_2010_rewardEval_0
#define COMPONENT_RELEASE 0
#define COMPONENT_REVISION 1
#define COMPONENT_ADDITIONAL "Author=alex\n" "URL=Not supplied\n"
#define COMPONENT_FLAGS (F_NOT_RATE_CHANGER)

//	we define this symbol to ask the template to include the basics
//	we usually need to build a process. it will import the "brahms"
//	namespace and include the header files (SDK) for the data and util
//	classes from the Standard Library.
#define OVERLAY_QUICKSTART_PROCESS

//	include the component interface overlay (component bindings 1199)
#include "brahms-1199.h"

//	STL includes
#include <cmath>
#include <sstream>
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;



//	alias data and util namespaces to something briefer
namespace numeric = std_2009_data_numeric_0;
namespace spikes = std_2009_data_spikes_0;
namespace rng = std_2009_util_rng_0;



#define INPUTS 	0
#define POS 	1

////////////////	COMPONENT CLASS (DERIVES FROM Process)

class COMPONENT_CLASS_CPP : public Process
{

public:

	//	use ctor/dtor only if required
	COMPONENT_CLASS_CPP() {}
	~COMPONENT_CLASS_CPP() {}

	//	the framework event function
	Symbol event(Event* event);

private:

	UINT32 num_inputs;
	UINT32 row_length;
	UINT32 col_length;
	DOUBLE radius;
	UINT32 targetIndex;
	VDOUBLE biases;
	DOUBLE decay_fact;
	DOUBLE buildup_fact;
	vector < vector < DOUBLE > > targets;
	UINT32 currHit;
	DOUBLE prevPan;
	DOUBLE prevTilt;

	// inputs and an output port
	vector < numeric::Input > inputs;
	numeric::Input panIn;
	numeric::Input tiltIn;

	numeric::Output biasOut;
	numeric::Output repOut;

	//	INPUT SET HANDLES
	vector<Symbol>		hSets;

};



////////////////	EVENT

Symbol COMPONENT_CLASS_CPP::event(Event* event)
{
	switch(event->type)
	{
		case EVENT_STATE_SET:
		{

			currHit = 99;	
			prevPan = 0;
			prevTilt = 0;		

			hSets.resize(2);

			hSets[INPUTS] = iif.getSet("inputs");
			hSets[POS] = iif.getSet("pos");

			//	extract DataML
			EventStateSet* data = (EventStateSet*) event->data;
			XMLNode xmlNode(data->state);
			DataMLNode nodeState(&xmlNode);

			radius = nodeState.getField("radius").getDOUBLE();
			decay_fact = nodeState.getField("decay_factor").getDOUBLE();
			buildup_fact = nodeState.getField("buildup_factor").getDOUBLE();

			targetIndex = (UINT32) nodeState.getField("target_index").getDOUBLE();

			VDOUBLE temp;
			//	extract
			if (nodeState.getField("targets").isCellArray()) {
				UINT32 numCells = nodeState.getField("targets").getNumberOfElementsTotal();
				targets.resize(numCells);
				for (UINT32 i = 0; i < numCells; ++i) {
					targets[i].resize(3, 0);
					temp = nodeState.getField("targets").getCell(i).getArrayDOUBLE();
					if (temp.size() != 3) berr << "Target needs to be [x y input_index]";
					targets[i][0] = temp[0];
					targets[i][1] = temp[1];
					targets[i][2] = temp[2];

				}
			}

			//	ok
			return C_OK;
		}

		case EVENT_INIT_CONNECT:
		{
			//	on first call
			if (event->flags & F_FIRST_CALL)
			{


				
				//	validate inputs
				if(iif.getNumberOfPorts(hSets[INPUTS]) < 2) berr << "Requires multiple inputs.";
				num_inputs = iif.getNumberOfPorts(hSets[INPUTS]);
				inputs.resize(num_inputs);
				biases.resize(num_inputs, 0);
				for (UINT32 i = 0; i < num_inputs; ++i) {
					if (i == 3 || i == 4 || i == 6) {
						biases[i] = 0.3;
					}
				}

				if(iif.getNumberOfPorts(hSets[POS]) > 2) berr << "Too many position inputs.";

				//	create outputs, real scalar DOUBLE
				biasOut.setName("bias");
				biasOut.create(hComponent);
				biasOut.setStructure(TYPE_REAL | TYPE_DOUBLE, Dims(num_inputs).cdims());

				repOut.setName("report");
				repOut.create(hComponent);
				repOut.setStructure(TYPE_REAL | TYPE_DOUBLE, Dims(10).cdims());


			}

			//	on last call
			if (event->flags & F_LAST_CALL)
			{

				// fetch inputs
				for (UINT32 i = 0; i < num_inputs; ++i) {

					inputs[i].selectSet(hSets[INPUTS]);
					inputs[i].attach(hComponent, i);
					inputs[i].validateStructure(TYPE_REAL | TYPE_DOUBLE);
				
				}

				// extract length of array side so we can strip off the first row
				const numeric::Structure* structure = inputs[0].getStructure(); 
				row_length = structure->dims.dims[0];
				col_length = structure->dims.dims[1];

				panIn.selectSet(hSets[POS]);
				panIn.attach(hComponent, "pan");
				panIn.validateStructure(TYPE_REAL | TYPE_DOUBLE, Dims(1).cdims());

				tiltIn.selectSet(hSets[POS]);
				tiltIn.attach(hComponent, "tilt");
				tiltIn.validateStructure(TYPE_REAL | TYPE_DOUBLE, Dims(1).cdims());


			}

			//	ok
			return C_OK;
		}

		case EVENT_RUN_SERVICE:
		{


			
			//	get data object on input ports and access its content
			vector < DOUBLE* > ins;
			ins.resize(num_inputs);
	
			for (UINT32 i = 0; i < num_inputs; ++i) {
				ins[i] = (DOUBLE*) inputs[i].getContent();
			}

			DOUBLE* pan = (DOUBLE*) panIn.getContent();
			DOUBLE* tilt = (DOUBLE*) tiltIn.getContent();


			//	get data object on output port and write its content
			DOUBLE* out = (DOUBLE*) biasOut.getContent();
			DOUBLE* report = (DOUBLE*) repOut.getContent();

			// work out what we really hit
			UINT32 hitIndex = 99;
			for (UINT32 i = 0; i < targets.size(); ++i) {
				DOUBLE sum = pow(targets[i][0] - pan[0],2);
				sum += pow(targets[i][1] - tilt[0],2);
				if (sum < pow(radius,2)) {
					hitIndex = targets[i][2];
					//bout << "hitTarg = " << double(i) << " " << double(hitIndex) << D_WARN;
					break;
				}
			}

			for (UINT32 i = 0; i < 4; ++i) report[i] = 0;

			// write report if target hit changes:
			DOUBLE currTime = time->now / sampleRateToRate(time->sampleRate);
			// also check if motors are moving
			if (currHit != hitIndex && abs(prevPan - pan[0]) == 0 && abs(prevTilt - tilt[0]) == 0) {
				currHit = hitIndex;
				UINT32 convertedHit = 99;
				if (currHit == 3) convertedHit = 5;
				if (currHit == 4) convertedHit = 6;
				if (currHit == 6) convertedHit = 9;
				report[0] = convertedHit;
				report[1] = currTime;
				report[2] = pan[0];
				report[3] = tilt[0];
			}
			

			// work out what we think we are looking at, but only if we are stopped
			UINT32 lookIndex = 99;
			if (abs(prevPan - pan[0]) == 0 && abs(prevTilt - tilt[0]) == 0) {
				DOUBLE bestVal = 0;
				for (UINT32 i = 0; i < num_inputs; ++i) {
					DOUBLE sum = 0;
					for (UINT32 j = 0; j < row_length; ++j) {
						for (UINT32 k = 0; k < 2; ++k) {

							sum += ins[i][j*col_length + k];

						}
					}
					sum /= row_length;

					// HACK - remove unwanted indices

					if (i != 3 && i != 4 && i != 6) {
						sum = 0;
					}

					if (i == 3) report[5] = sum;
					if (i == 4) report[6] = sum;
					if (i == 6) report[7] = sum;


					// /HACK

					// is value significant?
					if (sum > 0.06) {

						// if larger than last one, update index
						if (sum > bestVal) {
							bestVal = sum;
							lookIndex = i;
						}
					}
				}	
			}


			// now we know what we are looking at, and what the model *THINKS* it is looking at,
			// evaluate reward
			if (hitIndex == targetIndex) {
				// check we think we are looking at something
				if (lookIndex != 99) {
					// bias 
					biases[lookIndex] += buildup_fact;
				}
			}
			DOUBLE bsum = 0;
			// normalise biases
			for (UINT32 i = 0; i < num_inputs; ++i) {

				//biases[i] *= decay_fact;
				if (i == 3 || i == 4 || i == 6) {
					bsum += biases[i];
				}

			}
			for (UINT32 i = 0; i < num_inputs; ++i) {
				if (i == 3 || i == 4 || i == 6) {
					biases[i] /= bsum;
				}
			}

			for (UINT32 i = 0; i < num_inputs; ++i)	out[i] = biases[i] + 0.1;

			prevPan = pan[0];
			prevTilt = tilt[0];

//for (UINT32 i = 0; i < num_inputs; ++i)out[i] = 0;

//if (hitIndex != 99) out[hitIndex] = 1;

			//	ok
			return C_OK;
		}

	}

	//	if we service the event, we return C_OK
	//	if we don't, we should return S_NULL to indicate that we didn't
	return S_NULL;
}







//	include the second part of the overlay (it knows you've included it once already)
#include "brahms-1199.h"

