
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% A OCM-CUDA  example template scrip %
%%%%%%%%%%% Alex Cope 2010 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
executionStop = 1000;
fS = 400;
num_samples = fS * executionStop;

layerDims = [128 128];
layerLocs = {layerDims};

% Namespace paths:
p2a = 'dev/abrg/2009/modlin/activation/';
p2o = 'dev/abrg/2009/modlin/output/';
p2p = 'dev/abrg/2009/modlin/projection/';

%% BUILDING THE SYSTEM

sys = sml_system; % our top level system

state = {};
defParsAct = [];
defParsAct.tau_membrane = 0.05;
defParsAct.p = 1;
defParsAct.sigma_membrane = 0;

defParsOut = [];
defParsOut.limits = [0 1];
defParsOut.m = 1;
defParsOut.c = 0;

sys = nw_modAddPop(sys, 'layer1', fS, [layerDims], layerLocs, [p2a 'leaky'], defParsAct, [p2o 'linear'], defParsOut);
sys = nw_modAddPop(sys, 'layer2', fS, [layerDims], layerLocs, [p2a 'leaky'], defParsAct, [p2o 'linear'], defParsOut);

projState = {};
projState.sigma = 2.0;

sys = nw_modAddProj(sys, fS, 'layer1', 'layer2', 0.4, [p2p 'onetoone'], projState, 'add');



state = {};
state.data = double(rand(layerDims).*0.1);

state.data(20:25,20:25) = 0.4;

% state.data(10:15,50:55) = 0.3;

% state.data(75:80,50:55) = 0.2;
% 
% state.data(70:75,80:85) = 0.3;

state.ndims = 2;
state.repeat = true;

sys = sys.addprocess('src', 'std/2009/source/numeric', fS, state);

sys = sys.link('src>out', 'layer1/act<<add<in', 0);

%% CONFIGURE AND LAUNCH BRAHMS
cmd = brahms_execution;
cmd.name = 'modlin_test';
cmd.stop = executionStop;
cmd.all = false;
cmd.encapsulated = false;
cmd.execPars.MaxThreadCount = 'x2'; % Max two threads per processor


% call BRAHMS
brahms(sys, cmd);


%% PROCESS RESULTS

