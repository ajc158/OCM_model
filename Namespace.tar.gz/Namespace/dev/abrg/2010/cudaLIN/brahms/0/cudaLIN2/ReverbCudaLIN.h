/*

	This file is an interface to a CUDA LIN system creation library 

	Programmed By: David R W Barr (University of Manchester) and Alex Cope (University of Sheffield) 

	- 2010 -


*/

#define CHECK_EXT extern "C"

#ifdef __cplusplus


#include <string>
#include <iostream>
#include <vector>

using namespace std;

#define UINT32 int

#else

#endif

#ifdef _WIN32
	#define OS_MALLOC _aligned_malloc
	#define OS_FREE _aligned_free
#else
	#define OS_MALLOC cudaMallocHost
	#define OS_FREE cudaFreeHost
#endif




#ifndef REVERB_CUDA_H
#define REVERB_CUDA_H

// output function identifiers
#define LINEAR		0
#define TANH		1
#define EXP			2


// projection type identifiers
#define ONETOONE	0
#define DIFFUSE		1
#define GAUSSIAN	2
#define CUBEMAX		3

// synapse type identifiers
#define ADD			0
#define SHUNT		1

struct cudaLINlayer {

	string 	name;
	int		sizeX;
	int		sizeY;
	float	lambda_m;
	float   p;
	float 	c;
	float 	m;
	int		type;

};

struct cudaLINproj {

	string 	name;
	int		srcID;
	int 	dstID;
	int		type;
	int 	syn;
	float	weight;
	vector < float > extra;	

}; 

struct cudaLINin {

	string 	name;
	int 	dstID;
	float * data;

}; 

struct cudaLINout {

	string 	name;
	int 	srcID;
	float * data;

}; 


// Construct the model with all layers of the specified dimensions
CHECK_EXT void CreateSystem(vector < cudaLINlayer > layers, vector < cudaLINproj > projs);

// Use the parameters above
//CHECK_EXT void REVERB_SetParameter(int parameter, float value);

// Release all memory used by the model
CHECK_EXT void DestroySystem();

// Probe the output of a specific layer
CHECK_EXT void ProbeSystem(cudaLINout out, int width, int height);

// Perform one update cycle using a pre-normalised stimulus
CHECK_EXT string StepSystem(vector < cudaLINlayer > layers, vector < cudaLINproj > projs, vector < cudaLINin > inputs);


#endif
