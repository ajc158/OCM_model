% compile before run
!./build

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% A CUDALIN  example template script %
%%%%%%%%%%% Alex Cope 2010 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
executionStop = 1000;
fS = 400;
num_samples = fS * executionStop;

dims = [128 128];

%% BUILDING THE SYSTEM

sys = sml_system; % our top level system

state = {};

state.layers.layer1.tau_membrane = 0.05;
state.layers.layer1.output_type = 'linear';
state.layers.layer1.dims = dims;
state.layers.layer1.c = 0.0;
state.layers.layer1.m = 1.0;
state.layers.layer1.p = 1.0;

state.layers.layer2.tau_membrane = 0.05;
state.layers.layer2.output_type = 'linear';
state.layers.layer2.dims = dims;
state.layers.layer2.c = 0.0;
state.layers.layer2.m = 1.0;
state.layers.layer2.p = 1.0;

state.projections.one2two.src = 'layer1';
state.projections.one2two.dst = 'layer2';
state.projections.one2two.type = 'diffuse';
state.projections.one2two.weight = 0.00001;
state.projections.one2two.syn = 'add';
state.projections.one2two.size = 2.0;

state.inputs.in1.dst = 'layer1';

state.outputs.out1.src = 'layer2';

sys = sys.addprocess('cudaLIN', 'dev/abrg/2010/cudaLIN', fS, state);


state = {};
state.data = single(rand(dims).*0.1);

state.data(20:25,20:25) = 0.4;

% state.data(10:15,50:55) = 0.3;

% state.data(75:80,50:55) = 0.2;
% 
 state.data(70:75,80:85) = 0.3;

state.ndims = 2;
state.repeat = true;

sys = sys.addprocess('src', 'std/2009/source/numeric', fS, state);

sys = sys.link('src>out', 'cudaLIN<in1', 0);
% 
%     state.dims = [128 128];
%     state.scale=[0 1.01];
%     state.zoom = 1;
%     state.interval = 20;
%     state.position = [0 0];
%     state.colours = 'fire';
%     state.title = 'VISUAL INPUT';
%     sys = sys.addprocess('scopeVIS', 'dev/abrg/2009/scopeS', fS, state);
%     sys = sys.link('cudaLIN>out1', 'scopeVIS<<mono<in');

%% CONFIGURE AND LAUNCH BRAHMS
cmd = brahms_execution;
cmd.name = 'cuda_test';
cmd.stop = executionStop;
cmd.all = false;
cmd.encapsulated = false;
cmd.execPars.MaxThreadCount = 'x2'; % Max two threads per processor


% call BRAHMS
for i = 1:1
[out, rep] = brahms(sys, cmd);
end

%% PROCESS RESULTS


imagesc(out.cudaLIN.out1(:,:,300)); colormap(hot); colorbar
