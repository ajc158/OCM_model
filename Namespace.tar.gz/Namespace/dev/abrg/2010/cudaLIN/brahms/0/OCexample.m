
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% A CUDALIN OCM sys template script  %
%%%%%%%%%%% Alex Cope 2010 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
executionStop = 10;
fS = 400;
num_samples = fS * executionStop;

dims = [128 128];
dopamine = 0.2;

%% BUILDING THE SYSTEM

sys = sml_system; % our top level system

layerDef = {};

layerDef.tau_membrane = 0.05;
layerDef.output_type = 'linear';
layerDef.dims = dims;
layerDef.c = 0.0;
layerDef.m = 1.0;

state = {};

% layers

state.layers.FEF = layerDef;
state.layers.THAL = layerDef;
state.layers.D1 = layerDef;
state.layers.D2 = layerDef;
state.layers.STN = layerDef;
state.layers.GPE = layerDef;
state.layers.SNR = layerDef;
state.layers.SCB = layerDef;
state.layers.SCS = layerDef;

% lots of projections!

state.projections.FEF2THAL.src = 'FEF';
state.projections.FEF2THAL.dst = 'THAL';
state.projections.FEF2THAL.type = 'onetoone';
state.projections.FEF2THAL.weight = 8.0;
state.projections.FEF2THAL.syn = 'add';

state.projections.THAL2FEF.src = 'THAL';
state.projections.THAL2FEF.dst = 'FEF';
state.projections.THAL2FEF.type = 'onetoone';
state.projections.THAL2FEF.weight = 0.25;
state.projections.THAL2FEF.syn = 'add';

state.projections.FEF2D1.src = 'FEF';
state.projections.FEF2D1.dst = 'D1';
state.projections.FEF2D1.type = 'onetoone';
state.projections.FEF2D1.weight = 1.5 * (1+dopamine);
state.projections.FEF2D1.syn = 'add';

state.projections.THAL2D1.src = 'THAL';
state.projections.THAL2D1.dst = 'D1';
state.projections.THAL2D1.type = 'onetoone';
state.projections.THAL2D1.weight = 1.0 * (1+dopamine);
state.projections.THAL2D1.syn = 'add';

state.projections.FEF2D2.src = 'FEF';
state.projections.FEF2D2.dst = 'D2';
state.projections.FEF2D2.type = 'onetoone';
state.projections.FEF2D2.weight = 1.5 * (1-dopamine);
state.projections.FEF2D2.syn = 'add';

state.projections.THAL2D2.src = 'THAL';
state.projections.THAL2D2.dst = 'D2';
state.projections.THAL2D2.type = 'onetoone';
state.projections.THAL2D2.weight = 1.0 * (1-dopamine);
state.projections.THAL2D2.syn = 'add';

state.projections.FEF2STN.src = 'FEF';
state.projections.FEF2STN.dst = 'STN';
state.projections.FEF2STN.type = 'gaussian';
state.projections.FEF2STN.weight = 10;
state.projections.FEF2STN.syn = 'add';
state.projections.FEF2STN.sigma = 3.0;

state.projections.THAL2STN.src = 'THAL';
state.projections.THAL2STN.dst = 'STN';
state.projections.THAL2STN.type = 'gaussian';
state.projections.THAL2STN.weight = 10;
state.projections.THAL2STN.syn = 'add';
state.projections.THAL2STN.sigma = 3.0;

state.projections.D12SNR.src = 'D1';
state.projections.D12SNR.dst = 'SNR';
state.projections.D12SNR.type = 'onetoone';
state.projections.D12SNR.weight = -1.0;
state.projections.D12SNR.syn = 'add';

state.projections.D22GPE.src = 'D2';
state.projections.D22GPE.dst = 'GPE';
state.projections.D22GPE.type = 'onetoone';
state.projections.D22GPE.weight = -1.0;
state.projections.D22GPE.syn = 'add';

state.projections.STN2SNR.src = 'STN';
state.projections.STN2SNR.dst = 'SNR';
state.projections.STN2SNR.type = 'diffuse';
state.projections.STN2SNR.weight = 1.8/(dims(1)*dims(2));
state.projections.STN2SNR.syn = 'add';

state.projections.STN2GPE.src = 'STN';
state.projections.STN2GPE.dst = 'GPE';
state.projections.STN2GPE.type = 'diffuse';
state.projections.STN2GPE.weight = 1.0/(dims(1)*dims(2));
state.projections.STN2GPE.syn = 'add';

state.projections.GPE2STN.src = 'GPE';
state.projections.GPE2STN.dst = 'STN';
state.projections.GPE2STN.type = 'onetoone';
state.projections.GPE2STN.weight = -1.4;
state.projections.GPE2STN.syn = 'add';

state.projections.GPE2SNR.src = 'GPE';
state.projections.GPE2SNR.dst = 'SNR';
state.projections.GPE2SNR.type = 'onetoone';
state.projections.GPE2SNR.weight = -0.4;
state.projections.GPE2SNR.syn = 'add';

state.projections.SNR2THAL.src = 'SNR';
state.projections.SNR2THAL.dst = 'THAL';
state.projections.SNR2THAL.type = 'onetoone';
state.projections.SNR2THAL.weight = -2.5;
state.projections.SNR2THAL.syn = 'shunt';

state.projections.SNR2SCB.src = 'SNR';
state.projections.SNR2SCB.dst = 'SCB';
state.projections.SNR2SCB.type = 'onetoone';
state.projections.SNR2SCB.weight = -5.0;
state.projections.SNR2SCB.syn = 'shunt';

state.projections.FEF2SCB.src = 'FEF';
state.projections.FEF2SCB.dst = 'SCB';
state.projections.FEF2SCB.type = 'gaussian';
state.projections.FEF2SCB.weight = 10;
state.projections.FEF2SCB.syn = 'add';
state.projections.FEF2SCB.sigma = 0.6;

state.projections.SCB2SCB.src = 'SCB';
state.projections.SCB2SCB.dst = 'SCB';
state.projections.SCB2SCB.type = 'gaussian';
state.projections.SCB2SCB.weight = 1;
state.projections.SCB2SCB.syn = 'add';
state.projections.SCB2SCB.sigma = 2.0;

state.projections.SCS2SCB.src = 'SCS';
state.projections.SCS2SCB.dst = 'SCB';
state.projections.SCS2SCB.type = 'gaussian';
state.projections.SCS2SCB.weight = 10;
state.projections.SCS2SCB.syn = 'add';
state.projections.SCS2SCB.sigma = 0.6;

state.projections.SCS2THAL.src = 'SCS';
state.projections.SCS2THAL.dst = 'THAL';
state.projections.SCS2THAL.type = 'onetoone';
state.projections.SCS2THAL.weight = 1.0;
state.projections.SCS2THAL.syn = 'add';

% add an input 
state.inputs.FEF.dst = 'FEF';

% add an output
state.outputs.out1.src = 'FEF';

% create process
sys = sys.addprocess('cudaLIN', 'dev/abrg/2010/cudaLIN', fS, state);

% create a source
state = {};
state.data = single(rand(128).*0.05);

state.data(20:25,50:55) = 0.4;

state.data(70:75,50:55) = 0.3;

state.data(70:75,80:85) = 0.3;

state.data(1) = 1;
state.ndims = 2;
state.repeat = true;

sys = sys.addprocess('src', 'std/2009/source/numeric', fS, state);

% join it up
sys = sys.link('src>out', 'cudaLIN<FEF', 0);

% scopes work with doubles, so segfaults for now!

%     state.dims = [128 128];
%     state.scale=[0 1.01];
%     state.zoom = 1;
%     state.interval = 20;
%     state.position = [0 0];
%     state.colours = 'fire';
%     state.title = 'VISUAL INPUT';
%     sys = sys.addprocess('scopeVIS', 'dev/abrg/2009/scope', fS, state);
%     sys = sys.link('cudaLIN>out1', 'scopeVIS<<mono<in');

%% CONFIGURE AND LAUNCH BRAHMS
cmd = brahms_execution;
cmd.name = 'modlin_test';
cmd.stop = executionStop;
cmd.all = false;
cmd.encapsulated = false;
cmd.execPars.MaxThreadCount = 'x2'; % Max two threads per processor


% call BRAHMS
[out, rep] = brahms(sys, cmd);


%% PROCESS RESULTS


imagesc(out.cudaLIN.out1(:,:,600)); colormap(hot); colorbar
