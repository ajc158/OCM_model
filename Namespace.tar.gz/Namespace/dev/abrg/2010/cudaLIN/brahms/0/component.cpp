/* 
________________________________________________________________

	This file is part of BRAHMS
	Copyright (C) 2007 Ben Mitchinson
	URL: http://brahms.sourceforge.net

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
________________________________________________________________

	Subversion Repository Information (automatically updated on commit)

	$Id:: process.cpp 2067 2009-06-13 23:50:44Z benjmitch      $
	$Rev:: 2067                                                $
	$Author:: benjmitch                                        $
	$Date:: 2009-06-14 00:50:44 +0100 (Sun, 14 Jun 2009)       $
________________________________________________________________

*/



////////////////	COMPONENT INFO

//	define your component information here. if you use the BRAHMS
//	Manager to create your process, it will insert sensible defaults.
#define COMPONENT_CLASS_STRING "dev/abrg/2010/cudaLIN"
#define COMPONENT_CLASS_CPP dev_abrg_2010_cudaLIN_0 
#define COMPONENT_RELEASE 0
#define COMPONENT_REVISION 1
#define COMPONENT_ADDITIONAL "Author=alex\n" "URL=Not supplied\n"
#define COMPONENT_FLAGS (F_NOT_RATE_CHANGER)

//	we define this symbol to ask the template to include the basics
//	we usually need to build a process. it will import the "brahms"
//	namespace and include the header files (SDK) for the data and util
//	classes from the Standard Library.
#define OVERLAY_QUICKSTART_PROCESS

#define _CRT_SECURE_NO_DEPRECATE

//	include the core overlay (component bindings 1199)
#include "brahms-1199.h"

   /*
//	windows only
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include "windows.h"
#undef RGB
#endif */

//	STL includes
#include <ctime>
#include <cmath>
#include <sstream>
#include <iostream>
#include <vector>
#include <time.h>
#include <stdlib.h>
#include <ctime>

using namespace std;


//	alias data and util namespaces to something briefer
namespace numeric = std_2009_data_numeric_0;
namespace spikes = std_2009_data_spikes_0;
namespace rng = std_2009_util_rng_0;

////////////////	COMPONENT CLASS (DERIVES FROM Process)

#include "ReverbCudaLIN.h"

class COMPONENT_CLASS_CPP : public Process
{


public:

	//	use ctor/dtor only if required
	COMPONENT_CLASS_CPP() {}
	~COMPONENT_CLASS_CPP() {}

	//	the framework event function
	Symbol event(Event* event);




private:

	vector < cudaLINlayer > layers;
	vector < cudaLINproj > projs;
	vector < cudaLINin > inputs;
	vector < cudaLINout > outputs;

	vector < numeric::Input >  bInputs;
	vector < numeric::Output > bOutputs;

};


////////////////	EVENT

Symbol COMPONENT_CLASS_CPP::event(Event* event)
{
	switch(event->type)
	{
		case EVENT_STATE_SET:
		{
			
			//	extract DataML
			EventStateSet* data = (EventStateSet*) event->data;
			XMLNode xmlNode(data->state);
			DataMLNode nodeState(&xmlNode);

			// load in layers
			VSTRING layerState = nodeState.getField("layers").getFieldNames();
			layers.resize(layerState.size());

			for (UINT32 i=0; i < layerState.size(); ++i) {

				DataMLNode lNode = nodeState.getField("layers").getField(layerState[i].c_str());
				layers[i].name = layerState[i].c_str();
				Dims dims = lNode.getField("dims").getArrayDims();
				if (dims.size() != 2) berr << "cudaLIN: Incorrect dims for layer " << layers[i].name.c_str();
				layers[i].sizeX = dims[0];
				layers[i].sizeY = dims[1];

				if (dims[0] != dims[1]) berr << "cudaLIN: requires square layers with dimensions in multiples of 16. Layer '" << layers[i].name.c_str() << "' does not conform.";

				if (dims[0]%16 != 0) berr << "cudaLIN: requires square layers with dimensions in multiples of 16. Layer '" << layers[i].name.c_str() << "' does not conform.";

				DOUBLE tau_m = lNode.getField("tau_membrane").getDOUBLE();
				layers[i].lambda_m = exp(-1.0 / (tau_m * sampleRateToRate(time->sampleRate)));

				layers[i].c = lNode.getField("c").getDOUBLE();		
				layers[i].p = lNode.getField("p").getDOUBLE();		
				layers[i].m = lNode.getField("m").getDOUBLE();
				string tempS = lNode.getField("output_type").getSTRING();

				if (tempS.compare("linear")==0) {
					layers[i].type=LINEAR;}
				else if (tempS.compare("exp")==0) {
					layers[i].type=EXP;}
				else if (tempS.compare("tanh")==0) {
					layers[i].type=TANH;}
				else berr << "cudaLIN: output function type not recognised for layer " << layers[i].name.c_str();
			
			}


			// load in projections
			VSTRING projState = nodeState.getField("projections").getFieldNames();
			projs.resize(projState.size());

			for (UINT32 i=0; i < projState.size(); ++i) {

				DataMLNode pNode = nodeState.getField("projections").getField(projState[i].c_str());
				projs[i].name = projState[i].c_str();




				string tempS = pNode.getField("src").getSTRING();	

				bool found = false;
				for (UINT32 j=0; j < layers.size(); ++j) {

					if (tempS.compare(layers[j].name.c_str())==0) {	
						found = true;
						projs[i].srcID = j;
						break;}
				
				}			
		
				if (!found) berr << "cudaLIN: source not found for projection " << projs[i].name.c_str();





				tempS = pNode.getField("dst").getSTRING();	

				found = false;
				for (UINT32 j=0; j < layers.size(); ++j) {

					if (tempS.compare(layers[j].name.c_str())==0) {	
						found = true;
						projs[i].dstID = j;
						break;}
				
				}			
		
				if (!found) berr << "cudaLIN: destination not found for projection " << projs[i].name.c_str();


				projs[i].weight = pNode.getField("weight").getDOUBLE();			

				tempS = pNode.getField("type").getSTRING();

				if (tempS.compare("onetoone")==0) {
					projs[i].type=ONETOONE;
					// we've already checked squareness, so only one dim check in needed.
					if (layers[projs[i].srcID].sizeX != layers[projs[i].dstID].sizeX) {
					berr << "cudaLIN: onetoone projection type requires identical layer dimensions. Proj '" << projs[i].name.c_str() << "' does not conform.";}

					}
				else if (tempS.compare("diffuse")==0) {
					projs[i].type=DIFFUSE;}
				else if (tempS.compare("gaussian")==0) {
					projs[i].type=GAUSSIAN;}
				else if (tempS.compare("max")==0) {
					projs[i].type=CUBEMAX;}
				else berr << "cudaLIN: projection type not recognised for projection " << projs[i].name.c_str();

				tempS = pNode.getField("syn").getSTRING();

				if (tempS.compare("add")==0) {
					projs[i].syn=ADD;}
				else if (tempS.compare("shunt")==0) {
					projs[i].syn=SHUNT;}
				else berr << "cudaLIN: projection synapse not recognised for projection " << projs[i].name.c_str();


				// projection specific extras: gaussian
				if (projs[i].type == GAUSSIAN) {
					projs[i].extra.resize(1);
					projs[i].extra[0] = pNode.getField("sigma").getDOUBLE();}		

				// projection specific extras: max
				if (projs[i].type == CUBEMAX) {
					projs[i].extra.resize(1);
					projs[i].extra[0] = ceil(pNode.getField("size").getDOUBLE());}		
				
			
			}




			// load in inputs
			VSTRING inState = nodeState.getField("inputs").getFieldNames();
			inputs.resize(inState.size());

			for (UINT32 i=0; i < inState.size(); ++i) {

				DataMLNode pNode = nodeState.getField("inputs").getField(inState[i].c_str());
				inputs[i].name = inState[i].c_str();



				string tempS = pNode.getField("dst").getSTRING();	

				bool found = false;
				for (UINT32 j=0; j < layers.size(); ++j) {

					if (tempS.compare(layers[j].name.c_str())==0) {	
						found = true;
						inputs[i].dstID = j;
						break;}
				
				}			
		
				if (!found) berr << "cudaLIN: destination not found for input " << inputs[i].name.c_str();			
			
			}


			// load in outputs
			VSTRING outState = nodeState.getField("outputs").getFieldNames();
			outputs.resize(outState.size());

			for (UINT32 i=0; i < outState.size(); ++i) {

				DataMLNode pNode = nodeState.getField("outputs").getField(outState[i].c_str());
				outputs[i].name = outState[i].c_str();



				string tempS = pNode.getField("src").getSTRING();	

				bool found = false;
				for (UINT32 j=0; j < layers.size(); ++j) {

					if (tempS.compare(layers[j].name.c_str())==0) {	
						found = true;
						outputs[i].srcID = j;
						break;}
				
				}			
		
				if (!found) berr << "cudaLIN: source not found for output " << outputs[i].name.c_str();			
			
			}

			CreateSystem(layers, projs);
			
			return C_OK;
		}

		case EVENT_INIT_CONNECT:
		{
			//	on first call
			if (event->flags & F_FIRST_CALL)
			{

				bOutputs.resize(outputs.size());
				for (UINT32 i = 0; i < outputs.size(); ++i) {
					bOutputs[i].setName(outputs[i].name.c_str());
					bOutputs[i].create(hComponent);
					bOutputs[i].setStructure(TYPE_SINGLE | TYPE_REAL, Dims(layers[outputs[i].srcID].sizeX, layers[outputs[i].srcID].sizeY).cdims());

				}

			}

			//	on last call
			if (event->flags & F_LAST_CALL)
			{
				bInputs.resize(inputs.size());
				for (UINT32 i = 0; i < inputs.size(); ++i) {
					bInputs[i].attach(hComponent, inputs[i].name.c_str());
					bInputs[i].validateStructure(TYPE_SINGLE | TYPE_REAL, Dims(layers[inputs[i].dstID].sizeX, layers[inputs[i].dstID].sizeY).cdims());}

			}

			//	ok
			return C_OK;
		}


		case EVENT_INIT_POSTCONNECT:
		{



			return C_OK;
		}

		case EVENT_RUN_SERVICE:
		{
			usleep(3000);

			for (UINT32 i = 0; i < inputs.size(); ++i) {	
				inputs[i].data = (SINGLE*) bInputs[i].getContent();}

			string error = StepSystem(layers, projs, inputs);

			if (error.compare("fine")==0) {
					error = "cool";}
			else {
				berr << "CUDA error: " << error.c_str();}
			
			for (UINT32 i = 0; i < outputs.size(); ++i) {	
				outputs[i].data = (SINGLE*) bOutputs[i].getContent();

				ProbeSystem(outputs[i], layers[outputs[i].srcID].sizeX, layers[outputs[i].srcID].sizeY);}		

 			//	ok
			return C_OK;
		}

		case EVENT_RUN_STOP:
		{

			DestroySystem();

			return C_OK;
		}

	}


	//	if we service the event, we return C_OK
	//	if we don't, we should return S_NULL to indicate that we didn't
	return S_NULL;
}







//	include the second part of the overlay (it knows you've included it once already)
#include "brahms-1199.h"

