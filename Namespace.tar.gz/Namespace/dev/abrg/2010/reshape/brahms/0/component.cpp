
/*

	This is a newly created BRAHMS Process. It is a native
	process, and needs to be built before BRAHMS can run it.
	In Matlab, run "brahms_manager", select this component,
	and click on "Build". After doing this, you can build it
	in future using "brahms_utils".

*/



////////////////	COMPONENT INFO

//	define your component information here. if you use the BRAHMS
//	Manager to create your process, it will insert sensible defaults.
#define COMPONENT_CLASS_STRING "dev/abrg/2010/reshape"
#define COMPONENT_CLASS_CPP dev_abrg_2010_reshape_0
#define COMPONENT_RELEASE 0
#define COMPONENT_REVISION 1
#define COMPONENT_ADDITIONAL "Author=alex\n" "URL=Not supplied\n"
#define COMPONENT_FLAGS (F_NOT_RATE_CHANGER)

//	we define this symbol to ask the template to include the basics
//	we usually need to build a process. it will import the "brahms"
//	namespace and include the header files (SDK) for the data and util
//	classes from the Standard Library.
#define OVERLAY_QUICKSTART_PROCESS

//	include the component interface overlay (component bindings 1199)
#include "brahms-1199.h"



//	alias data and util namespaces to something briefer
namespace numeric = std_2009_data_numeric_0;
namespace spikes = std_2009_data_spikes_0;
namespace rng = std_2009_util_rng_0;





////////////////	COMPONENT CLASS (DERIVES FROM Process)

class COMPONENT_CLASS_CPP : public Process
{

public:

	//	use ctor/dtor only if required
	COMPONENT_CLASS_CPP() {}
	~COMPONENT_CLASS_CPP() {}

	//	the framework event function
	Symbol event(Event* event);

private:

	

	VDOUBLE dims;



	//	an input and an output port
	numeric::Input input;
	numeric::Output output;




};



////////////////	EVENT

Symbol COMPONENT_CLASS_CPP::event(Event* event)
{
	switch(event->type)
	{
		case EVENT_STATE_SET:
		{
			//	extract DataML
			EventStateSet* data = (EventStateSet*) event->data;
			XMLNode xmlNode(data->state);
			DataMLNode nodeState(&xmlNode);



			//	extract a scalar and a matrix of real doubles of size 8x3
			dims = nodeState.getField("output_dims").validate(TYPE_DOUBLE | TYPE_REAL, Dims(2, 1)).getArrayDOUBLE();







			//	ok
			return C_OK;
		}

		case EVENT_INIT_CONNECT:
		{
			//	on first call
			if (event->flags & F_FIRST_CALL)
			{


				
				//	validate that exactly one input was provided
				if (iif.getNumberOfPorts() != 1)
					berr << "expected 1 input";

				//	create one output, real scalar DOUBLE
				output.setName("out");
				output.create(hComponent);
				output.setStructure(TYPE_REAL | TYPE_UINT8, Dims(dims[0],dims[1]).cdims());



			}

			//	on last call
			if (event->flags & F_LAST_CALL)
			{



				input.attach(hComponent, "in");
				//input.validateStructure(TYPE_REAL | TYPE_UINT8, Dims(4, 2).cdims());



			}

			//	ok
			return C_OK;
		}

		case EVENT_RUN_SERVICE:
		{


			
			//	get data object on input port and access its content
			UINT8* in = (UINT8*) input.getContent();


			//	get data object on output port and write its content
			UINT8* out = (UINT8*) output.getContent();
			out = in;



			//	ok
			return C_OK;
		}

	}

	//	if we service the event, we return C_OK
	//	if we don't, we should return S_NULL to indicate that we didn't
	return S_NULL;
}







//	include the second part of the overlay (it knows you've included it once already)
#include "brahms-1199.h"

